% NWChem Parser

function nwcinfo=nwc_parse(nwc_output)

% Reading in NWChem output file
file_id=fopen(nwc_output,'r');
nwctext=textscan(file_id,'%s','delimiter','\n');
fclose(file_id); nwctext=nwctext{1};

% Removing empty lines
parfor ii=1:numel(nwctext)
    nwctext(ii)=deblank(nwctext(ii)); 
end

% Declaring substring arrays as unique identifiers
coor_substr='Output coordinates in angstroms';
cst_substr='Total Shielding Tensor'; nwcinfo.cst={};


% Extracting Number of Isotopes/Atoms
% Must sit alone due to pulling number of atoms for later parsing
natoms=0;

for ii=1:length(nwctext)-1 % Minus one so it does not crash if reaches end
   currentline=nwctext(ii);
   nextline=nwctext(ii+1);
   if contains(currentline,'property')&&contains(nextline,'SHIELDING') %%%%
       stringline=string(nextline); % Convert to string
       splitline=strsplit(stringline); % Split string by ' ' delimiter
       natoms_str=splitline(end); % Take the last int as str
       natoms=str2num(natoms_str); % % Needs to be int
   end
end

% Assert the number atoms is no longer zero
assert(natoms~=0,'   - Number of atoms not found or equal to zero.')
coup_freqs=zeros(natoms,natoms); % Declaring couplings

% Begin looping here:
for ii=1:length(nwctext)
    currentline=nwctext(ii);
    temp=strsplit(string(nwctext(ii)));
    
    % Extracting Isotopes/Atoms & Coordinates
    if contains(currentline,coor_substr)
        % Indexing ii+3+natoms; up to and including
        nwcinfo.coor_cellarr=nwctext(ii+4:ii+3+natoms);
        
    % Extracting Full Chemical Shielding Tensors
    % NOTE: Shielding Tensors only calculated for C&H; must match in
    % handle_parsed.m
    elseif contains(currentline,cst_substr)
        % Appending ...
        nwcinfo.cst=[nwcinfo.cst,[nwctext(ii+1); nwctext(ii+2); nwctext(ii+3)]];
        
    % Extracting Coupling Frequencies matrix
    elseif logical(temp(1)=="Atom"&&temp(5)=="Atom")
        col_idx=str2num(erase(temp(2),":")); % Needs to be int
        row_idx=str2num(erase(temp(6),":")); % Needs to be int
        temp_freq=strsplit(string(nwctext(ii+41)));
        assert(temp_freq(2)=='Spin-Spin',...
            '   - Exact line for coupling frequencies not found: Change search parameters in line above.')
        temp_freq=str2double(temp_freq(5));
        % Accounting for symmetry by switching row/column index
        coup_freqs(row_idx,col_idx)=coup_freqs(row_idx,col_idx)+temp_freq;
        coup_freqs(col_idx,row_idx)=coup_freqs(col_idx,row_idx)+temp_freq;
    end
end

% Assert size of coordinate cell array matches number of atoms
assert(length(nwcinfo.coor_cellarr)==natoms,...
    '   - Coordinate cell array size does not match number of atoms.')

% Ensuring diaganolized zeros
for ii=1:natoms
    if logical(coup_freqs(ii,ii)~=0)
        disp('   - Extracted Coupling Frequency incorrect: overwriting to zero.')
        coup_freqs{ii,ii}=0; 
    end
end

% Must convert before passing: why? Good question *shrek voice*
nwcinfo.cf=coup_freqs;

end