## Plotting histograms of NMR spectra from ./../*.csv

import numpy as np
import pandas as pd
import pdb
import matplotlib.pyplot as plt
import os
import glob
import argparse

spec_directory='./../*.csv'
spectra_files=glob.glob(spec_directory)

parser=argparse.ArgumentParser(description=' ~~~ Some non-shitty description ~~~')
parser.add_argument('-idim','--imagedimension',metavar='',required=False,type=int,default=512,help='Pixel dimension of spectra - assuming square; default 512')
parser.add_argument('-nbins','--numberofbins',metavar='',required=False,type=int,default=50,help='Number of bins in each histogram')
args=parser.parse_args()

idim=args.imagedimension
nbins=args.numberofbins

def extract_spectra(filelist):
    spectra=[]

    for ii in range(len(filelist)):
        tempspec=pd.read_csv(filelist[ii],header=None)
        for jj in range(3): # Rotate the reference frame to match
            tempspec=np.rot90(tempspec)
        spectra.append(tempspec)

    return spectra

def plot_histograms(spec):
    for idx in range(len(spec)):
        plt.hist(spec[idx].flatten(),bins=nbins,color='grey')
        plt.title(spectra_files[idx].split('/')[-1][:-12])
        #plt.savefig('{}_hist.png'.format(spectra_files[idx].split('/')[-1][:-12]))
        plt.show()

    return

if __name__=='__main__':
    spectra=extract_spectra(spectra_files)
    plot_histograms(spectra)

    pdb.set_trace()
