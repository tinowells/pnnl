% NWChem2Spinach, main script

% Input - string path to NWChem output file

function nwc_info=n2s_main(nwcoutfile)

% Sending NWChem output file to parser
nwcparsed=nwc_parse(nwcoutfile);

% Reformatting parsed information for Spinach
nwc_info=handle_parsed(nwcparsed.coor_cellarr,...
    nwcparsed.cst,nwcparsed.cf);
clear nwcparsed;

% Redeclaring variables for clarity
isos=nwc_info.isotopes;
coords=nwc_info.coordinates;
cf=nwc_info.spinspin;
cst=nwc_info.cst_manu;

% Newest scripts
n2s_cosy90(isos,coords,cst,cf);
n2s_noesy(isos,coords,cst,cf);
n2s_hmbc(isos,coords,cst,cf);
n2s_hsqc(isos,coords,cst,cf);

% check with constance and see if matlab can run there

end