% HMBC spectrum of sucrose with natural content of 13C isotope
% (magnetic parameters computed with DFT).
%
% Calculation time: seconds
%
% Initially created by:
% Bud Macaulay
% i.kuprov@soton.ac.uk
%
% Modifications made by:
% Tino Wells
% < tino.wells@pnnl.gov >
% PNNL

function n2s_hmbc(isos,coords,cst,cf)

sys.isotopes=isos;
inter.coordinates=coords;
inter.coupling.scalar=cf;
inter.zeeman.matrix=cst;

% Magnet field
sys.magnet=5.9;

% Algorithmic options
sys.enable={'greedy'};
sys.tols.prox_cutoff=4.0;

% Basis set
bas.formalism='sphten-liouv';
bas.approximation='IK-2';
bas.connectivity='scalar_couplings';
bas.space_level=1;

% Sequence parameters
parameters.J=140;
parameters.delta_b=60e-3;
parameters.sweep=[4000 2000];
parameters.offset=[5000 900];
parameters.npoints=[128 128];
parameters.zerofill=[512 512];
parameters.spins={'13C','1H'};
parameters.axis_units='ppm';

% Create the spin system structure
spin_system=create(sys,inter);

% Generate isotopomers
subsystems=dilute(spin_system,'13C');

% Preallocate the answer
spectrum=zeros(parameters.zerofill(2),parameters.zerofill(1));

% Loop over isotopomers
parfor n=1:numel(subsystems)
    
    % Build the basis
    subsystem=basis(subsystems{n},bas);
    
    % Simulation
    fid=liquid(subsystem,@hmbc,parameters,'nmr');
    
    % Apodization
    fid=apodization(fid,'cosbell-2d');
    
    % Fourier transform
    spectrum=spectrum+fftshift(fft2(fid,parameters.zerofill(2),parameters.zerofill(1)));
    
end

% Destreaking
spectrum=destreak(spectrum);

% Plotting
hmbc_fig=figure();
plot_2d(spin_system,abs(spectrum),parameters,20,[0.05 1.0 0.05 1.0],2,256,6,'positive');
saveas(hmbc_fig,'~/Downloads/hmbc.png')

end

