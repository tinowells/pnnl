% Calculation time: a minute
% 
% Modifications made by:
% Tino Wells
% <tino.wells@pnnl.gov>

function nwchem2cosy(isotopes,coordinates,coup_freqs,cst)
tic; % Timing
% Initializing Simulation Variables
sys.isotopes=isotopes;
inter.coordinates=coordinates;
inter.coupling.scalar=coup_freqs;
inter.zeeman.matrix=cst;

% Algorithmic options
sys.magnet=5.9;
sys.enable={'greedy'};
sys.tols.prox_cutoff=4.0;

% Basis set
bas.formalism='sphten-liouv';
bas.approximation='IK-2';
bas.space_level=1;
bas.connectivity='scalar_couplings';
bas.sym_group={'S3','S3','S3'}; %Methyl group symmetry
bas.sym_spins={[14 15 16],[17 18 19],[20 21 22]};

% Sequence parameters
parameters.angle=pi/4; % Pulse flip angle
parameters.offset=1200; % Not listed
parameters.sweep=2000; % sweep width in each dimension of the spectrum (Hz)
parameters.npoints=[128 128]; % number of points in each dimension of output data array (image resolution)
parameters.zerofill=[512 512]; % NOT LISTED
parameters.spins={'1H'}; % Spins that are to be assigned to each instrument channel during the simulations
parameters.axis_units='ppm'; % Also not listed. 

% Spinach housekeeping
spin_system=create(sys,inter);
spin_system=basis(spin_system,bas);

% Simulation
fid=liquid(spin_system,@cosy,parameters,'nmr');

% Apodization
fid=apodization(fid,'cosbell-2d');

% Fourier transform
spectrum=fftshift(fft2(fid,parameters.zerofill(2),parameters.zerofill(1)));

% Destreaking
spectrum=destreak(spectrum);

% Plotting
cosy_fig = figure(); 
plot_2d(spin_system,abs(spectrum),parameters,20,[0.0025 0.05 0.0025 0.05],2,256,6,'positive');
saveas(cosy_fig,'~/Downloads/testsave_COSY.png')
fprintf('\nCOSY Simulation Time: %.3f seconds\n',toc);
end
