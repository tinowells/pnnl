% Handling Parse NWChem data - correcting format for spinach

% Checklist:
% Isotopes/Atoms: check
% Chemical shielding tensors: check
% Coordinates: check
% Couplings matrix: check-a-roo

function spindata=handle_parsed(coorcellarr,cscellarr,coup_freq,opts)
tic;

% Extracting Atoms from coorcellarr and reformatting
isos={};
keep_index=[];
for ii=1:length(coorcellarr)
   strspl=strsplit(string(coorcellarr(ii)));
   atom=strspl(2);
   if atom=='C'
       isos=[isos, '13C'];
       keep_index=[keep_index, ii];
   elseif atom=='H'
       isos=[isos, '1H'];
       keep_index=[keep_index, ii];
   end
end

% Extracting/Decompressing Coordinates from coorcellarr and reformatting
coorcellarr=coorcellarr(keep_index); % removing bad indicies
coup_freq=coup_freq(keep_index,keep_index); % Removing any non-C/H^^^
coords=cell(length(coorcellarr),1);
for ii=1:length(coords)
   temp=strsplit(string(coorcellarr(ii)));
   temp=temp(4:6);
   coords{ii}=[str2double(temp)];
end

% Extracting/Compressing Shielding Tensors
cstensor=cell(length(cscellarr),1);
for ii=1:length(cscellarr)
    line1=str2double(strsplit(string(cscellarr(1,ii))));
    line2=str2double(strsplit(string(cscellarr(2,ii))));
    line3=str2double(strsplit(string(cscellarr(3,ii))));
    cstensor{ii}=[line1;line2;line3];
end

%if ~exist('opts') opts=[]; end


% Appending Spin Data
spindata.isotopes=isos;
spindata.coordinates=reshape(coords, [1 length(coords)]);
spindata.cst=reshape(cstensor,[1 length(cstensor)]);
spindata.spinspin=num2cell(coup_freq);

fprintf('\nHandling time: %.3 seconds\n',toc);
end