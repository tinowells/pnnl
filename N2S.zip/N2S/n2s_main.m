% NWChem2Spinach, main script

% Input - string path to NWChem output file

function nwc_info=n2s_main(nwcoutfile,test_cf)
tic;
% Sending NWChem output file to parser
nwcparsed=nwc_parse(nwcoutfile);

% Reformatting parsed information for Spinach
nwc_info=handle_parsed(nwcparsed.coor_cellarr,...
    nwcparsed.cst,nwcparsed.cf);

% Redeclaring variables for clarity
isos=nwc_info.isotopes;
coords=nwc_info.coordinates;
cf=nwc_info.spinspin;
cst=nwc_info.cst;

% Testing: OUR DATA - delete test_ss out of function call
%nwchem2cosy(isos,coords,cf,cst);
%nwchem2nosey(isos,coords,cf,cst);
%nwchem2hsqc(isos,coords,cf,cst);
%nwchem2hmbc(isos,coords,cf,cst);

% Testing Script: Our data w/ their data, just making sure it works
nwchem2cosy(isos,coords,test_cf,cst);% check
nwchem2nosey(isos,coords,test_cf,cst);% check
nwchem2hsqc(isos,coords,test_cf,cst);% check
nwchem2hmbc(isos,coords,test_cf,cst);% check
fprintf('\n\nN2S Runtime: %.3f seconds\n\n\n',toc);
end